function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6ErJlOTVdc0":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

